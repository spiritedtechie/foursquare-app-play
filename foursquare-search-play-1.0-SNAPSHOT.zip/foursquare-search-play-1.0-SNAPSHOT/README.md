# Description

This application is a "popular places search" web application that integrates against the Foursquare API.
It is built using the Play Framework, utilising the MVC pattern and Bootstrap 3 for presentation.

# Technologies Overview
Scala
PlayFramework libraries
HTML
Javascript
Bootstrap
Testing using Specs2

# Patterns and Techniques Used
MVC
Adaptor
Dependency Injection
TDD
Functional Programming

# Setup
- Install activator using Homebrew
    brew install typesafe-activator
- Ensure Java 8 SDK is installed and set as JAVA_HOME
    export JAVA_HOME=/location
- Run the tests (from the project root)
    activator test
- Run a specific test
    activator "test-only BrowserFunctionalSpec"
- Run the application in auto-compile mode
    activator run
- Create a distribution zip for the application
    sbt universal:packageBin

# Distribution

There is a distribution zip file in the project root which contains a runnable application

- Unzip the zip
- Run from the root folder:
    

